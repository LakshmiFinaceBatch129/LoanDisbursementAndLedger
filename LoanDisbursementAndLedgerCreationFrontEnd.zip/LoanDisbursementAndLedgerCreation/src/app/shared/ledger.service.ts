import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DisbursementDetails } from '../model/disbursement-details';

@Injectable({
  providedIn: 'root'
})
export class LedgerService {

  constructor(private http:HttpClient) { }

getLedgerDetails():Observable<DisbursementDetails[]>
{

 return this.http.get<DisbursementDetails[]>("http://localhost:9090/disbursementdetail/");

}




}
