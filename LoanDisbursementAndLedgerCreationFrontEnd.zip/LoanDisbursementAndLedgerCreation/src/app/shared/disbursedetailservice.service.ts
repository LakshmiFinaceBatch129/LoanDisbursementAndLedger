import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DisbursementDetails } from '../model/disbursement-details';

@Injectable({
  providedIn: 'root'
})
export class DisbursedetailserviceService {

  constructor(private http:HttpClient) { }



  saveDisburseDetails(obj:DisbursementDetails):Observable<DisbursementDetails>
  {
return this.http.post<DisbursementDetails>("http://localhost:9090/disbursementdetail/", obj);
  }


}
