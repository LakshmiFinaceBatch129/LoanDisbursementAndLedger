import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DisbursementDetailRoutingModule } from './disbursement-detail-routing.module';
import { DisbursementDetailComponent } from './disbursement-detail/disbursement-detail.component';
import { SactiondisbursementComponent } from './sactiondisbursement/sactiondisbursement.component';
import { ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    DisbursementDetailComponent,
    SactiondisbursementComponent
  ],
  imports: [
    CommonModule,
    DisbursementDetailRoutingModule,ReactiveFormsModule
  ]
})
export class DisbursementDetailModule { }
