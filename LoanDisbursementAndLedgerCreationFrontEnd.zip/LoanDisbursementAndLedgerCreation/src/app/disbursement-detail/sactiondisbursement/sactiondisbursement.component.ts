import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { DisbursedetailserviceService } from 'src/app/shared/disbursedetailservice.service';

@Component({
  selector: 'app-sactiondisbursement',
  templateUrl: './sactiondisbursement.component.html',
  styleUrls: ['./sactiondisbursement.component.css']
})
export class SactiondisbursementComponent implements OnInit {
sanctionForm:FormGroup;
  constructor(private fb:FormBuilder,private location:Location,private disburseservice:DisbursedetailserviceService) { }

  ngOnInit(): void
   {

    this.sanctionForm=this.fb.group({           //disbursedetail class

id:[],                    
date:[''],
emidate:[''],
emiAmount:[''],
loanFile:this.fb.group({    
                           //onetoone mapping with loanFile Class
  loanFileId:[],
  customerLoanAmount:[''],
  loanTenure:[''],
  loansactiondate:[''],
  loanStatus:[''],
  disburseStatus:[''],

  customers:this.fb.group({                    //one to mapping of loanfile class with customer class

    cid:[''],
    name:[''],
    productName:[''],
    productPrice:[''],
    email:[''],
    mobile:[''],
    aadharNo:[''],
    accountNo:[''],
    city:['']

  })

})

    })



    let loanFileObj:any=this.location.getState();
    console.log(loanFileObj)
    this.sanctionForm.get('loanFile').get('loanFileId').setValue(loanFileObj.loanFileId);
    this.sanctionForm.get('loanFile').get('customerLoanAmount').setValue(loanFileObj.customerLoanAmount);
    this.sanctionForm.get('loanFile').get('loanTenure').setValue(loanFileObj.loanTenure);
    this.sanctionForm.get('loanFile').get('loansactiondate').setValue(loanFileObj.loansactiondate);
    this.sanctionForm.get('loanFile').get('loanStatus').setValue(loanFileObj.loanStatus);
    this.sanctionForm.get('loanFile').get('disburseStatus').setValue(loanFileObj.disburseStatus);
    this.sanctionForm.get('loanFile').get('customers').get('cid').setValue(loanFileObj.customers.cid);
    
    this.sanctionForm.get('loanFile').get('customers').get('name').setValue(loanFileObj.customers.name);
    this.sanctionForm.get('loanFile').get('customers').get('productName').setValue(loanFileObj.customers.productName);
    this.sanctionForm.get('loanFile').get('customers').get('productPrice').setValue(loanFileObj.customers.productPrice);
    this.sanctionForm.get('loanFile').get('customers').get('email').setValue(loanFileObj.customers.email);
    this.sanctionForm.get('loanFile').get('customers').get('mobile').setValue(loanFileObj.customers.mobile);
    this.sanctionForm.get('loanFile').get('customers').get('aadharNo').setValue(loanFileObj.customers.aadharNo);
    this.sanctionForm.get('loanFile').get('customers').get('accountNo').setValue(loanFileObj.customers.accountNo);
    this.sanctionForm.get('loanFile').get('customers').get('city').setValue(loanFileObj.customers.city);


  }

//   initEmailDetails()
//   {
//     return this.fb.group({
//       emidate:[''],
//       amount:['']
//        }   );
//   }
//   get formArr()
//   {
//     return  <FormArray>this.sanctionForm.get('emi') ;
//  }
//  addEmi() {
  
//   this.formArr.push(this.initEmailDetails())
// }

// removeEmi(i: number) 
// {
//   this.formArr.removeAt(i);
// }


onSanction()
{
  if(this.sanctionForm.valid)
  {
    console.log(this.sanctionForm.value)
   this.disburseservice.saveDisburseDetails(this.sanctionForm.value).subscribe();
   window.location.reload();
  }

}





}

