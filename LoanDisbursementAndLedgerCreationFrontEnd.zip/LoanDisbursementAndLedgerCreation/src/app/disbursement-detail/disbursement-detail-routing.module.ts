import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DisbursementDetailComponent } from './disbursement-detail/disbursement-detail.component';
import { SactiondisbursementComponent } from './sactiondisbursement/sactiondisbursement.component';

const routes: Routes = [
  {path:'',component:DisbursementDetailComponent,children:[{path:'sanction',component:SactiondisbursementComponent}]}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DisbursementDetailRoutingModule { }
