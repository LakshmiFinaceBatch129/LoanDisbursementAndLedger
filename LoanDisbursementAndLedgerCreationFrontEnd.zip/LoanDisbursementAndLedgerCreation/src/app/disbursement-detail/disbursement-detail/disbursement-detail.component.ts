import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/common.service';
import { LoanFile } from 'src/app/model/loan-file';

@Component({
  selector: 'app-disbursement-detail',
  templateUrl: './disbursement-detail.component.html',
  styleUrls: ['./disbursement-detail.component.css']
})
export class DisbursementDetailComponent implements OnInit {
loanFileList:LoanFile[];
  constructor(private common:CommonService) { }

  ngOnInit(): void 
  {
    this.common.getLoanFile().subscribe(data=>this.loanFileList=data);
  }
 

}
