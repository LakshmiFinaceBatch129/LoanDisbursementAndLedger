import { Routes } from "@angular/router";
import { DashboardComponent } from "src/app/dashboard/dashboard.component";

export const contentroutes:Routes=[
    {
       path:'',redirectTo:'disbursedetail',pathMatch:'full'
    },
  
    {
        path:"dashboard",component:DashboardComponent
    },
    
    {
    path:'disbursedetail',loadChildren:()=>import('src/app/disbursement-detail/disbursement-detail.module').then(m=>m.DisbursementDetailModule)
},
{
path:'disburse',loadChildren:()=>import('src/app/disburse/disburse.module').then(m=>m.DisburseModule)
}
]