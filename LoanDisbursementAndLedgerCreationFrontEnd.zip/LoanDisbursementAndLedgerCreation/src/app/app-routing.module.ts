import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HeaderComponent } from './header/header/header.component';
import { contentroutes } from './header/routes/content-routes';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';

const routes: Routes = [
  {
    path:'',redirectTo:"login",pathMatch:"full"
  },
  {
    path:'login',component:LoginComponent

},
{
path:'login/register',component:RegisterComponent
},
{
  path:'login/header',component:HeaderComponent,children:contentroutes
}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
