import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerForm:FormGroup;

  constructor(private _fb:FormBuilder, private common:CommonService) { }

  ngOnInit(): void {
    this.registerForm=this._fb.group(
      {
        id:[],
        name:['',Validators.required],
        email:['',Validators.required],
        mobile:['',Validators.required],
        address:this._fb.group({
          paddress:['',Validators.required],
          taddress:['',Validators.required],
         
        }),
         
       
        username:['',Validators.required],
        password:['',Validators.required]


      }
    )
  }
  onSubmit()
  {
    if(this.registerForm.valid)
    {

  }
  }

}
