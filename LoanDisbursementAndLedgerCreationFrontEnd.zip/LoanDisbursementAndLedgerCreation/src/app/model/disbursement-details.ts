
import { LoanFile } from "./loan-file";

export class DisbursementDetails
 {
     id:number;
     date:string;
     loanFile:LoanFile;
    emidate:string;
    emiAmount:string;



}
