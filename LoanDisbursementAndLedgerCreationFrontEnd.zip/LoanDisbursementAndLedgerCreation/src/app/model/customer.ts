export class Customer 
{
    cid:number;
    name:string;
    productName:string;
    mobile:string;
    email:string;
    aadharNo:string;
    accountNo:string;
    city:string;
}
