export class AccountHead
 {
    id:number;
    name:string;
	username:string;
	 password:string;
	 role:string;
   
}
