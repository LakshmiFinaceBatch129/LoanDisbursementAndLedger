export class EmiDetails 
{


    id:number;
    emidate:string;
    amount:string;
   
    

}
