import { EmiDetails } from './emi-details';

describe('EmiDetails', () => {
  it('should create an instance', () => {
    expect(new EmiDetails()).toBeTruthy();
  });
});
