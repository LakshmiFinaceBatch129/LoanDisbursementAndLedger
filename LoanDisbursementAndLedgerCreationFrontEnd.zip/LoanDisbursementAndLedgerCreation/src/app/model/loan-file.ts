import { Customer } from "./customer";

export class LoanFile 
{
    loanFileId:number;
    customerLoanAmount:number;
    loanTenure:Number;
    loansactiondate:string;
    loanStatus:string;
    disburseStatus:string;
    customers:Customer;
    

}
