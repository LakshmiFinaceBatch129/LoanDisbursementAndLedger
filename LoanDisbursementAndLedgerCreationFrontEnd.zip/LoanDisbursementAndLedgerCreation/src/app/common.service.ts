import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { LoanFile } from './model/loan-file';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor(private http:HttpClient) { 

  }

getLoanFile():Observable<LoanFile[]>
{
return this.http.get<LoanFile[]>("http://localhost:9090/loanfile/");
}


}
