import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { DisbursementDetails } from 'src/app/model/disbursement-details';
import { LedgerService } from 'src/app/shared/ledger.service';
import {jsPDF} from "jspdf";

@Component({
  selector: 'app-disburse',
  templateUrl: './disburse.component.html',
  styleUrls: ['./disburse.component.css']
})
export class DisburseComponent implements OnInit {

  constructor(private ledgerservice:LedgerService,private location:Location) { }
disberseObj:DisbursementDetails[];
  ngOnInit(): void 
  {
 this.ledgerservice.getLedgerDetails().subscribe(obj=>this.disberseObj=obj);




  }

  getback()
  {
this.location.back();
  }

  generateLeadger(d:DisbursementDetails)
  {
    console.log(d);
    console.log(d.loanFile.loanFileId);
    let pdf=new jsPDF();
    pdf.text("Laxmi Finance",10,10)
    pdf.text("Date:-"+d.date,160,10)
    pdf.text("Invoice",90,50);
    pdf.text("Invoice Number:    "+d.id,60,80);
    pdf.text("Loan Tenure:       "+d.loanFile.loanTenure,60,100);
    pdf.text("Customer Id:       "+d.loanFile.customers.cid,60,120);
    pdf.text("Customer Name:     "+d.loanFile.customers.name,60,140);
    pdf.text("Customer Address:  "+d.loanFile.customers.city,60,160);
    pdf.text("Account Number:    "+d.loanFile.customers.accountNo,60,180);
    pdf.text("Email ID :         "+d.loanFile.customers.email,60,200);
    pdf.text("Aadhar Number:     "+d.loanFile.customers.aadharNo,60,220);
    pdf.text("Mobile Number:     "+d.loanFile.customers.mobile,60,240)
    pdf.text("EMI Date:          "+d.emidate,60,260);
    pdf.text("Emi Amount:        "+d.emiAmount,60,280);
    
    pdf.save();
  }

}
