import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DisburseRoutingModule } from './disburse-routing.module';
import { DisburseComponent } from './disburse/disburse.component';


@NgModule({
  declarations: [
    DisburseComponent
  ],
  imports: [
    CommonModule,
    DisburseRoutingModule
  ]
})
export class DisburseModule { }
