import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../shared/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm:FormGroup;
  msg:string;

  constructor(private _fb:FormBuilder,private router:Router,private users:UserService) { }

  ngOnInit(): void {
    this.createLoginForm();
  }

  createLoginForm()
  {
this.loginForm=this._fb.group(
  {
    username:['', Validators.required],
    password:['', Validators.required]
  }
)
  }
  onSubmit()
  {
  let uname=  this.loginForm.get('username').value;
  console.log(uname);
  this.users.getUser(uname).subscribe(user=>{
    if(this.loginForm.get('username').value==user.username && this.loginForm.get('password').value==user.password)

     { 
  this.router.navigate(['login/header']);

     }


})

this.msg="Enter Valid Username And Password";



  
  }

}
