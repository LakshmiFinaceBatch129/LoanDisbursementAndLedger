package com.webcorestone.loandisbursement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoanDisbursementAndLedgerCreationApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoanDisbursementAndLedgerCreationApplication.class, args);
	}

}
