package com.webcorestone.loandisbursement.service;

import com.webcorestone.loandisbursement.mastermodel.User;

public interface UserService 
{

	User getUser(String username);
	

}
