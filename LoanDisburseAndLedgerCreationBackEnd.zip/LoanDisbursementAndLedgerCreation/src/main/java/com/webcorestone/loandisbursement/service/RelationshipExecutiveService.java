package com.webcorestone.loandisbursement.service;

public interface RelationshipExecutiveService {

}
