package com.webcorestone.loandisbursement.service;

public interface OperationExecutiveService {

}
